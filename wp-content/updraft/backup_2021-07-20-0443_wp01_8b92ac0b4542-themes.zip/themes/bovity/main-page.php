<?php 
// Template Name: Bovity Home Page
get_header();
	do_action( 'avata_avadanta_sections', false );
get_footer();