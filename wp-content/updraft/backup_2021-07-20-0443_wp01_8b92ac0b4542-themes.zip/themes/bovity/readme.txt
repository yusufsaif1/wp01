=== Bovity ===
Contributors: Avadantathemes
Requires at least: 5.0
Tested up to: 5.7.2
Requires PHP: 5.6
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Bovity WordPress Free theme under GPL V2 


== Description ==

Bovity - it solution and technology based wordpress theme designed for technology, startup, digital marketing, business-solution, it company,  business, consultant, corporate, agency, web agency and Services Company. It is a creative, fully customizable and multipurpose theme that you can use to create any kind of beautiful websites. pre-made designed Homepage with 7 inner sections slider, service, about, team, testimonial, portfolio, call to action, you can easily customize them. Unlimited color feature with unlimited typography. Compatible with gutenberg, elemnetor page builder and so many popular plugins nicely works with bovity theme.

Set Homepage Setup:-

1. Go to Dashboard >> Pages >> Add New, Create a new page and name it as "Home" then select the template "Bovity Home Page" and publish it.

2. Go to Dashboard >> Settings >> Reading, Select the option of Static Page, now select the page you Created As the Home page.


== Frequently Asked Questions ==

= Does this theme support any plugins? =

Bovity supports for Woocomerce, Elementor page builder plugin ans Also Other Plugins Too.

= Can I modify Theme? =

Bovity developed under th GPL terms so you can use it free and can modify or redistribute according to your needs. 


== Changelog ==

= 1.0.1 =
* resolved keyboard navigation
* search modal issue resolved

= 1.0.0 =
* Initial release


== Upgrade Notice ==

* No Upgrade In The Theme.



== Copyright ==
* Bovity WordPress Theme, Copyright 2021
* Bovity is distributed under the terms of the GNU GPL



== Resources ==
* Bootstrap , Copyright 2011-2019, Twitter, under MIT license ,http://getbootstrap.com


* Magnific Popup: msemenov.com/plugins/magnific-popup/ , 2013 Dmitry Semenov ,License: under MIT license , https://github.com/dimsemenov/Magnific-Popup/blob/master/LICENSEtml

* Owl Carousel : https://owlcarousel2.github.io/OwlCarousel2/ , Copyright 2013-2016 David Deutsch ,License: under MIT license , https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE


*Animate : http://daneden.me/animate , Copyright (c) 2016 Daniel Eden , License: under MIT license ,http://opensource.org/licenses/MIT

* Fontawesome : http://fontawesome.io/ , Copyright (C) 2018 By davegandy , License: MIT License ,[SIL OFL 1.1]


* Breadcrumb Trail : https://themehybrid.com/plugins/breadcrumb-trail , Copyright (c) 2008 - 2017, Justin Tadlock , License:  http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

    
* Customizer Repeater : https://github.com/cristian-ungureanu/customizer-repeater , Copyright (c) 2016 ,License:  https://github.com/cristian-ungureanu/customizer-repeater/blob/production/LICENSE

* Customizer Repeater : https://github.com/Codeinwp/customizer-controls/tree/master/customizer-alpha-color-picker , Copyright (c) 2016 ,
License:  https://github.com/Codeinwp/customizer-controls/blob/master/LICENSE

* customizer alpha color picker : https://www.jacklmoore.com/colorbox/ ,Copyright (c) 2016 Jack Moore ,License:  https://github.com/jackmoore/colorbox/blob/master/LICENSE.md


== Screenshot ==
Banner:
 https://pxhere.com/en/photo/26343
 License: https://pxhere.com/en/license
 Images Used CC0 License

== Header Default BG ==
  https://pxhere.com/en/photo/869393
  License: https://pxhere.com/en/license
  Images Used CC0 License

== 404 BG ==
  https://pxhere.com/en/photo/1169530
  License: https://pxhere.com/en/license
  Images Used CC0 License