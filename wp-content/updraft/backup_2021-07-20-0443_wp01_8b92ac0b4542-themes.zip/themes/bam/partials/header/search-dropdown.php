<div class="bam-search-button-icon">
    <i class="fa fa-search" aria-hidden="true"></i>
</div>
<div class="bam-search-box-container">
    <div class="bam-search-box">
        <?php get_search_form(); ?>
    </div><!-- th-search-box -->
</div><!-- .th-search-box-container -->
