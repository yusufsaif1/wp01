<div class="bam-authorbox clearfix">

    <div class="bam-author-img">
        <?php echo get_avatar( get_the_author_meta( 'ID' ), '100' ); ?>
    </div>

    <div class="bam-author-content">
        <h4 class="author-name"><?php echo esc_html( get_the_author() );?></h4>
        <p class="author-description"><?php the_author_meta( 'description' ); ?></p>
        <a class="author-posts-link" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" title="<?php echo esc_attr( get_the_author() ); ?>">
            <?php 
                /* translators: %s: author name */
                printf( esc_html__( 'View all posts by %s &rarr;', 'bam' ), esc_attr( get_the_author() ) ); 
            ?>
        </a>
    </div>

</div>