<?php

namespace ResponsiveMenu\Database\Migrations;

class Migrate_1_1_0_1_1_1 extends Migrate {

}
